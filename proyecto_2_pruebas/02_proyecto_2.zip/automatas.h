/*
Alexandro Francisco Marcelo Gonzalez A01021383
14/03/2019
*/

#ifndef AUTOMATAS_H
#define AUTOMATAS_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>

using namespace std;

class Automata
{
private:
    int numero_pasos_recursivos; //para saber cuantos pasos recursivos se han hecho
    string variables; //para todas las variables que tiene mi lenguaje que sustituyen los substrings
    //string NFANtablaTransicion[][];
    int N; //numero de estados
    int M; //numero de simbolos
    int K; //numero de estados finales
    vector<int> lista_estados_finales; //almaceno los estados finales
    int T; //numero de transiciones (flechas)
    vector<string> dfa_lista_transiciones; //almaceno la lista de transiciones
    vector<char> simbolos; //almaceno los simbolos de los inputs
    vector< vector<string> > dfa_estado_transicion; //almaceno la tabla de transicion del dfa para reconstruir y escribir el archivo de salida
public:
    Automata(){}
    ~Automata(){}
    
    void convertirAutomata(string archivo)
    {
        string ** NFANtablaTransiciones;
        NFANtablaTransiciones = leerArchivo(archivo);
        //printf("antes: %s\n", NFANtablaTransicion[0][2].c_str());
        extraerEstadoInicial(NFANtablaTransiciones);
        obtenerDFA(NFANtablaTransiciones);
        liberarMemoria(NFANtablaTransiciones);
    }

    void obtenerDFA(string ** NFANtablaTransiciones)
    {
        vector<string> dfa_auxiliar; //copia de las transiciones a DFA para hacer pop_back sin afectar al original y final
        vector<string> aux_dfa_estado_transicion; //guardar los estados generados en cada transicion del DFA (final)
        dfa_auxiliar = dfa_lista_transiciones;
        vector<int> estados_de_transicion_vector;
        vector<int> estados_dado_una_entrada_vector; //guardo los estados en un vector dado un input
        string estados_input;
        string estados_actuales;
        string str_estados_input = "";
        int posicion_estado_del_vector;
        int cont_y = 0;
        int cont_x = 0;

        string ** DFAtablaTransicion = new string*[N];
        for(int i = 0; i < N; i++)
        {
            DFAtablaTransicion[i] = new string[M];
            for(int j = 0; j < M; j++)
            {
                DFAtablaTransicion[i][j] = "@";
            }
        }
        DFAtablaTransicion[0][0] = dfa_auxiliar.back();
        while(dfa_auxiliar.size() > 0)
        {
            //printf("\nsize: %ld\n", dfa_auxiliar.size());
            estados_actuales = dfa_auxiliar.front();//guardo cada conjunto de estados del DFA //0,1,2,3,4,8,9
            printf("Conjunto: %s\n", estados_actuales.c_str());
            dfa_auxiliar.erase(dfa_auxiliar.begin());
            estados_de_transicion_vector = obtenerEstadosDeTransicion(estados_de_transicion_vector, estados_actuales); //0 1 2 3 4 8 9
            for(int i = 0; i < simbolos.size(); i++)
            {
                for(int j = 0; j < estados_de_transicion_vector.size(); j++)
                {
                    posicion_estado_del_vector = estados_de_transicion_vector[j]; //0 //1 //3 //4
                    estados_input = NFANtablaTransiciones[posicion_estado_del_vector][i]; //f //2 //f //5
                    //printf("estados_input(%d): %s ([%d][%d])\n", i, estados_input.c_str(), posicion_estado_del_vector, i);
                    if (estados_input != "f") 
                    {
                        estados_dado_una_entrada_vector.clear(); //checar por si falla
                        estados_dado_una_entrada_vector = obtenerEstadosDeTransicion(estados_dado_una_entrada_vector, estados_input);
                        str_estados_input = obtenerEstadosConMovimientosNulos(NFANtablaTransiciones, estados_dado_una_entrada_vector);
                        //printf("String: %s\n", str_estados_input.c_str());
                        
                        for(int p = 0; p < estados_dado_una_entrada_vector.size(); p++)
                        {
                            printf("VECTOR: %d_ ", estados_dado_una_entrada_vector[p]);
                        }
                        
                        str_estados_input = limpiarString(str_estados_input);
                        printf("String limpio: %s\n", str_estados_input.c_str());
                        if(!(find(aux_dfa_estado_transicion.begin(), aux_dfa_estado_transicion.end(), str_estados_input) != aux_dfa_estado_transicion.end())) 
                        {
                            aux_dfa_estado_transicion.push_back(str_estados_input);
                            dfa_auxiliar.push_back(str_estados_input);
                            DFAtablaTransicion[cont_y][i+1] = str_estados_input; //meto el conjunto que hace transicion dado un input
                            DFAtablaTransicion[aux_dfa_estado_transicion.size()][0] = str_estados_input; //meto el conjunto inicio
                            //cont_y++;
                            printf("METI: %s. HAY: %ld->size(aux_dfa...)\n", str_estados_input.c_str(), aux_dfa_estado_transicion.size());
                        }
                        else
                        {
                            printf("NO METI: %s\n",str_estados_input.c_str());
                        }
                        if (cont_y == 4) //cambiar para ques solamente haga en la ultima vez
                        {
                            printf("OP");
                            DFAtablaTransicion[cont_y][i+1] = str_estados_input; //meto el conjunto que hace transicion dado un input
                        }
                        cout << endl;
                        str_estados_input = "";
                    }
                }
                for(int k = 0; k < aux_dfa_estado_transicion.size(); k++)
                {
                    if(!(find(dfa_estado_transicion.begin(), dfa_estado_transicion.end(), aux_dfa_estado_transicion) != dfa_estado_transicion.end())) 
                    {
                        dfa_estado_transicion.push_back(aux_dfa_estado_transicion);
                        printf("*******%s**.\n",aux_dfa_estado_transicion.back().c_str());
                    }
                }
                //sleep(1);
            }
            cont_y++;
            printf("%d Vez**.\n", cont_y);
        }
        for(int i = 0; i < simbolos.size()+1; i++)
        {
            for(int k = 0; k < dfa_estado_transicion.size(); k++)
            {
                printf("%s (%d,%d)\t", dfa_estado_transicion[k][i].c_str(), k, i);
            }
            printf("\n");
        }
        printf("\nconjun\t\ta\t\tb\n");
        for(int i = 0; i < N; i++)
        {
            for(int j = 0; j < M; j++)
            {
                printf("%s\t\t",DFAtablaTransicion[i][j].c_str());
            }
            printf("\n");
        }
        liberarMemoria(DFAtablaTransicion);
    }

    string obtenerEstadosConMovimientosNulos(string ** NFANtablaTransiciones, vector<int> estados_dado_una_entrada_vector)
    {
        string estados_dado_una_entrada;
        int pos_estado_actual;
        string transicion_actual;

        for(int i = 0; i < estados_dado_una_entrada_vector.size(); i++)
        {
            estados_dado_una_entrada =  estados_dado_una_entrada + to_string(estados_dado_una_entrada_vector[i]) + ",";
        }

        while(estados_dado_una_entrada_vector.size() > 0)
        {
            pos_estado_actual = estados_dado_una_entrada_vector.back();
            estados_dado_una_entrada_vector.pop_back();
            transicion_actual = NFANtablaTransiciones[pos_estado_actual][M-1];
            if(transicion_actual != "f")
            {
                estados_dado_una_entrada_vector = obtenerEstadosDeTransicion(estados_dado_una_entrada_vector, transicion_actual);
                if (estados_dado_una_entrada.find(transicion_actual) == std::string::npos)
                    estados_dado_una_entrada = estados_dado_una_entrada + transicion_actual + ",";
            }
            //i = 0;//Checar por si falla
        }
        return estados_dado_una_entrada;
    }

    string limpiarString(string conjunto)
    {
        string aux = "";
        string aux_aux = "";
        string str_final = "";
        string x = ",";
        string cp_conjunto = conjunto;
        cp_conjunto = "," + cp_conjunto;
        for(int i = 0; i < conjunto.size(); i++)
        {
            if (conjunto[i] != ',') 
            {
                aux = aux + conjunto[i];
            }
            if (conjunto[i] == ',' || (i+1) == conjunto.size())
            {
                aux_aux = "," + aux + ",";
                //printf("aux_aux: %s\n", aux_aux.c_str());
                if(x.find(aux_aux) == std::string::npos) 
                {
                    x = x + aux + ",";
                    str_final = str_final + aux + ",";
                }
                aux_aux = "";
                aux = "";
            }
        }
        //printf("final: %s\n\n", str_final.c_str());
        return str_final;
    }

    vector<int> obtenerEstadosDeTransicion(vector<int> transiciones, string transicion_actual)
    {
        string str_estado_actual = "";
        int int_estado_actual;
        vector<int> estados_de_transicion = transiciones;
        for(int i = 0; i < transicion_actual.size(); i++)
        {
            if (transicion_actual[i] != ',') 
            {
                str_estado_actual = str_estado_actual + transicion_actual[i];
            }
            if (transicion_actual[i] == ',' || (i+1) == transicion_actual.size())
            {
                int_estado_actual = stoi(str_estado_actual);
                if(!(find(estados_de_transicion.begin(), estados_de_transicion.end(), int_estado_actual) != estados_de_transicion.end())) 
                {
                    estados_de_transicion.push_back(int_estado_actual);
                }
                str_estado_actual = "";
            }
        }
        return estados_de_transicion;
    }

    void extraerEstadoInicial(string ** NFANtablaTransiciones)
    {
        string transicion_actual;
        int pos_estado_actual;
        vector<int> estados_de_transicion;
        string conjunto_transiciones = "0,";

        estados_de_transicion.push_back(0);

        //for(int i = 0; i <= estados_de_transicion.size(); i++)
        while(estados_de_transicion.size() > 0)
        {
            pos_estado_actual = estados_de_transicion.back();
            estados_de_transicion.pop_back();
            transicion_actual = NFANtablaTransiciones[pos_estado_actual][M-1];
            if(transicion_actual != "f")
            {
                estados_de_transicion = obtenerEstadosDeTransicion(estados_de_transicion, transicion_actual);
                //printf("Size edos: %ld", estados_de_transicion.size());
                conjunto_transiciones = conjunto_transiciones + transicion_actual + ",";
            }
            //i = 0;//Checar por si falla
        }
        dfa_lista_transiciones.push_back(conjunto_transiciones);

        printf("0: %s\n", dfa_lista_transiciones[0].c_str());
        for(int i = 0; i < estados_de_transicion.size(); i++)
        {
            printf("%d: %d\n", i, estados_de_transicion[i]);
        }
    }

    void liberarMemoria(string** tabla)
    {
        if(tabla)
        {
            for(int i = 0; i < N; i++)
            { 
                if(tabla[i])
                { 
                    delete[] tabla[i]; 
                } 
            }
            delete[] tabla;
        }
    }
    string** leerArchivo(string archivo)
    {
        ifstream file;
        char simbolo;
        int nodo_inicio;
        int nodo_destino;
        int valor;
        int posicion_simbolo;
        file.open(archivo.c_str(), ios::in);

        if (file.fail()) 
        {
            cout << "No se encontro el archivo para leer" << endl;
            exit(1); //si no encontro el archivo cierra el programa
        }
        file >> N;
        file >> M;


        string ** NFANtablaTransicion = new string*[N];
        for(int i = 0; i < N; i++)
        {
            NFANtablaTransicion[i] = new string[M];
            for(int j = 0; j < M; j++)
            {
                NFANtablaTransicion[i][j] = "f";
            }
        }
        
        file >> K;
        //printf("K %d", K);
        for(int i = 0; i < K; i++)
        {
            file >> valor;
            lista_estados_finales.push_back(valor);
        }
        file >> T;
        for(int i = 0; i < T; i++)
        {
            file >> nodo_inicio >> nodo_destino >> simbolo;
            if (simbolo == 'f') 
            {
                if (NFANtablaTransicion[nodo_inicio][M-1] ==  "f") 
                {
                    NFANtablaTransicion[nodo_inicio][M-1] = to_string(nodo_destino);
                }
                else
                {
                    NFANtablaTransicion[nodo_inicio][M-1] = NFANtablaTransicion[nodo_inicio][M-1] + "," + to_string(nodo_destino);
                }
            }
            else
            {
                if(!(find(simbolos.begin(), simbolos.end(), simbolo) != simbolos.end())) 
                {
                    simbolos.push_back(simbolo);
                }
                posicion_simbolo = obtenerPosicionSimbolo(simbolo);
                printf("pos: %d", posicion_simbolo);
                if (NFANtablaTransicion[nodo_inicio][posicion_simbolo] ==  "f") 
                {
                    NFANtablaTransicion[nodo_inicio][posicion_simbolo] = to_string(nodo_destino);
                }
                else
                {
                    NFANtablaTransicion[nodo_inicio][posicion_simbolo] = NFANtablaTransicion[nodo_inicio][M-1] + "," + to_string(nodo_destino);
                }
            }   
        }
        printf("\nTabla de transicion de NFA-null:\n");
        printf("a\tb\tnull\t\n");
        for(int i = 0; i < N; i++)
        {
            for(int j = 0; j < M; j++)
            {
                printf("%s\t", NFANtablaTransicion[i][j].c_str());
            }
            printf("\n");
        }
        printf("\n");
        file.close();
        return NFANtablaTransicion;
    }

    int obtenerPosicionSimbolo(char simbolo)
    {
        int posicion;
        posicion = simbolo - 97;
        return posicion;
    }
    
};

#endif


/*

#ifndef AUTOMATAS_H
#define AUTOMATAS_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

class Automata
{
private:
    int numero_pasos_recursivos; //para saber cuantos pasos recursivos se han hecho
    string variables; //para todas las variables que tiene mi lenguaje que sustituyen los substrings
    string NFANtablaTransicion[1000][5];
    static int N; //numero de estados
    static int M; //numero de simbolos
    int K; //numero de estados finales
    vector<int> lista_estados_finales; //almaceno los estados finales
    int T; //numero de transiciones (flechas)
    vector<string> lista_transiciones; //almaceno los estados finales
    vector<string> simbolos;

public:
    Automata(){}
    ~Automata(){}
    
    void leerArchivo(string archivo)
    {
        ifstream file;
        char simbolo;
        int nodo_inicio;
        int nodo_destino;
        int valor;
        int posicion_simbolo;
        file.open(archivo.c_str(), ios::in);

        if (file.fail()) 
        {
            cout << "No se encontro el archivo para leer" << endl;
            exit(1); //si no encontro el archivo cierra el programa
        }
        file >> N;
        file >> M;
        //string NFANtablaTransicion[N][M];
        for(int i = 0; i < N; i++)
        {
            for(int j = 0; j < M; j++)
            {
                NFANtablaTransicion[i][j] = "f";
            }
        }
        
        file >> K;
        //printf("K %d", K);
        for(int i = 0; i < K; i++)
        {
            file >> valor;
            lista_estados_finales.push_back(valor);
        }
        file >> T;
        for(int i = 0; i < T; i++)
        {
            file >> nodo_inicio >> nodo_destino >> simbolo;
            if (simbolo == 'f') 
            {
                if (NFANtablaTransicion[nodo_inicio][M-1] ==  "f") 
                {
                    NFANtablaTransicion[nodo_inicio][M-1] = to_string(nodo_destino);
                }
                else
                {
                    NFANtablaTransicion[nodo_inicio][M-1] = NFANtablaTransicion[nodo_inicio][M-1] + "," + to_string(nodo_destino);
                }
            }
            else
            {
                posicion_simbolo = obtenerPosicionSimbolo(simbolo);
                if (NFANtablaTransicion[nodo_inicio][posicion_simbolo] ==  "f") 
                {
                    NFANtablaTransicion[nodo_inicio][posicion_simbolo] = to_string(nodo_destino);
                }
                else
                {
                    NFANtablaTransicion[nodo_inicio][posicion_simbolo] = NFANtablaTransicion[nodo_inicio][M-1] + "," + to_string(nodo_destino);
                }
            }   
        }
        printf("\nTabla de transicion de NFA-null:\n");
        printf("a\tb\tnull\t\n");
        for(int i = 0; i < N; i++)
        {
            for(int j = 0; j < M; j++)
            {
                printf("%s\t", NFANtablaTransicion[i][j].c_str());
            }
            printf("\n");
        }
        printf("\n");
        file.close();
        convertirAutomata();
    }

    int obtenerPosicionSimbolo(char simbolo)
    {
        int posicion;
        posicion = 97 - simbolo;
        return posicion;
    }

    void convertirAutomata()
    {
        printf("%s", NFANtablaTransicion[0][2].c_str());
    }
};

#endif




//2

#ifndef AUTOMATAS_H
#define AUTOMATAS_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

class Automata
{
private:
    int numero_pasos_recursivos; //para saber cuantos pasos recursivos se han hecho
    string variables; //para todas las variables que tiene mi lenguaje que sustituyen los substrings
    //string NFANtablaTransicion[][];
    int N; //numero de estados
    int M; //numero de simbolos
    int K; //numero de estados finales
    vector<int> lista_estados_finales; //almaceno los estados finales
    int T; //numero de transiciones (flechas)
    vector<string> lista_transiciones; //almaceno los estados finales
    vector<string> simbolos;

public:
    Automata(){}
    ~Automata(){}
    
    void convertirAutomata(string archivo)
    {
        leerArchivo(archivo);
    }

    void leerArchivo(string archivo)
    {
        ifstream file;
        char simbolo;
        int nodo_inicio;
        int nodo_destino;
        int valor;
        int posicion_simbolo;
        file.open(archivo.c_str(), ios::in);

        if (file.fail()) 
        {
            cout << "No se encontro el archivo para leer" << endl;
            exit(1); //si no encontro el archivo cierra el programa
        }
        file >> N;
        file >> M;
        string NFANtablaTransicion[N][M];
        for(int i = 0; i < N; i++)
        {
            for(int j = 0; j < M; j++)
            {
                NFANtablaTransicion[i][j] = "f";
            }
        }
        
        file >> K;
        //printf("K %d", K);
        for(int i = 0; i < K; i++)
        {
            file >> valor;
            lista_estados_finales.push_back(valor);
        }
        file >> T;
        for(int i = 0; i < T; i++)
        {
            file >> nodo_inicio >> nodo_destino >> simbolo;
            if (simbolo == 'f') 
            {
                if (NFANtablaTransicion[nodo_inicio][M-1] ==  "f") 
                {
                    NFANtablaTransicion[nodo_inicio][M-1] = to_string(nodo_destino);
                }
                else
                {
                    NFANtablaTransicion[nodo_inicio][M-1] = NFANtablaTransicion[nodo_inicio][M-1] + "," + to_string(nodo_destino);
                }
            }
            else
            {
                posicion_simbolo = obtenerPosicionSimbolo(simbolo);
                if (NFANtablaTransicion[nodo_inicio][posicion_simbolo] ==  "f") 
                {
                    NFANtablaTransicion[nodo_inicio][posicion_simbolo] = to_string(nodo_destino);
                }
                else
                {
                    NFANtablaTransicion[nodo_inicio][posicion_simbolo] = NFANtablaTransicion[nodo_inicio][M-1] + "," + to_string(nodo_destino);
                }
            }   
        }
        printf("\nTabla de transicion de NFA-null:\n");
        printf("a\tb\tnull\t\n");
        for(int i = 0; i < N; i++)
        {
            for(int j = 0; j < M; j++)
            {
                printf("%s\t", NFANtablaTransicion[i][j].c_str());
            }
            printf("\n");
        }
        printf("\n");
        file.close();
    }

    int obtenerPosicionSimbolo(char simbolo)
    {
        int posicion;
        posicion = 97 - simbolo;
        return posicion;
    }
    
};

#endif


*/

/*
        string transicion_actual;
        string conjunto_transiciones = "0,";
        for(int i = 0; i < M; i++)
        {
            transicion_actual = NFANtablaTransiciones[0][i];
            if(transicion_actual != "f")
            {
                conjunto_transiciones = conjunto_transiciones + transicion_actual + ",";
            }
        }
        dfa_lista_transiciones.push_back(conjunto_transiciones);

        //2
        for(int i = 0; i < estados_de_transicion.size(); i++)
        {
            transicion_actual = NFANtablaTransiciones[i][M-1];
            if(transicion_actual != "f")
            {
                estado_str = "";
                for(int j = 0; j < transicion_actual.size(); j++)
                {
                    if(transicion_actual[j] != ',')
                    {
                        estado_str = estado_str + transicion_actual[j];
                    }
                    else if(transicion_actual[j] == ',' || (j+1) == transicion_actual.size())
                    {
                        estado_int = stoi(estado_str);
                        estados_de_transicion.push_back(estado_int);
                        estado_str = "";
                    }
                }
                conjunto_transiciones = conjunto_transiciones + transicion_actual + ",";
            }
        }


//FF
void obtenerDFA(string ** NFANtablaTransiciones)
    {
        vector<string> dfa_auxiliar; //copia de las transiciones a DFA para hacer pop_back sin afectar al original y final
        vector<string> aux_dfa_estado_transicion; //guardar los estados generados en cada transicion del DFA (final)
        dfa_auxiliar = dfa_lista_transiciones;
        vector<int> estados_de_transicion_vector;
        vector<int> estados_dado_una_entrada_vector; //guardo los estados en un vector dado un input
        string estados_input;
        string estados_actuales;
        string str_estados_input = "";
        int posicion_estado_del_vector;
        int cont = -1;

        while(dfa_auxiliar.size() > 0)
        {
            printf("\nsize: %ld\n", dfa_auxiliar.size());
            estados_actuales = dfa_auxiliar.back(); //guardo cada conjunto de estados del DFA //0,1,2,3,4,8,9
            printf("kk: %s\n", estados_actuales.c_str());
            dfa_auxiliar.pop_back();
            estados_de_transicion_vector = obtenerEstadosDeTransicion(estados_de_transicion_vector, estados_actuales); //0 1 2 3 4 8 9
            for(int i = 0; i < simbolos.size(); i++)
            {
                for(int j = 0; j < estados_de_transicion_vector.size(); j++)
                {
                    posicion_estado_del_vector = estados_de_transicion_vector[j]; //0 //1 //3 //4
                    estados_input = NFANtablaTransiciones[posicion_estado_del_vector][i]; //f //2 //f //5
                    //printf("estados_input(%d): %s ([%d][%d])\n", i, estados_input.c_str(), posicion_estado_del_vector, i);
                    if (estados_input != "f") 
                    {
                        estados_dado_una_entrada_vector.clear(); //checar por si falla
                        estados_dado_una_entrada_vector = obtenerEstadosDeTransicion(estados_dado_una_entrada_vector, estados_input);
                        str_estados_input = obtenerEstadosConMovimientosNulos(NFANtablaTransiciones, estados_dado_una_entrada_vector);
                        //printf("String: %s\n", str_estados_input.c_str());
                        str_estados_input = limpiarString(str_estados_input);
                        printf("String: %s\n", str_estados_input.c_str());
                        if(!(find(aux_dfa_estado_transicion.begin(), aux_dfa_estado_transicion.end(), str_estados_input) != aux_dfa_estado_transicion.end())) 
                        {
                            aux_dfa_estado_transicion.push_back(str_estados_input);
                            dfa_auxiliar.push_back(str_estados_input);
                            printf("METI: %s, HAY %ld size aux dfa...\n", str_estados_input.c_str(), aux_dfa_estado_transicion.size());
                        }
                        str_estados_input = "";
                    }
                }
                cont++;
                printf("%d Vez**.\n", cont);
                for(int k = 0; k < aux_dfa_estado_transicion.size(); k++)
                {
                    if(!(find(dfa_estado_transicion.begin(), dfa_estado_transicion.end(), aux_dfa_estado_transicion) != dfa_estado_transicion.end())) 
                    {
                        dfa_estado_transicion.push_back(aux_dfa_estado_transicion);
                        printf("*******%s**.\n",aux_dfa_estado_transicion.back().c_str());
                    }
                }
                
                
                sleep(1);
            }
        }
        for(int i = 0; i < simbolos.size()+1; i++)
        {
            for(int k = 0; k < dfa_estado_transicion.size(); k++)
            {
                printf("%s([%d][%d])\t", dfa_estado_transicion[k][i].c_str(), k, i);
            }
            printf("\n");       
        }
    }

        */

