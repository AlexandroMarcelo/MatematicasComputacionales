#include "automatas.h"
  #include <cstdio>
#include <cstdlib>

int** createTable(int rows, int columns){
    int** table = new int*[rows];
    for(int i = 0; i < rows; i++) {
        table[i] = new int[columns]; 
        for(int j = 0; j < columns; j++){ table[i][j] = (i+j); }// sample set value;    
    }
    return table;
}
void freeTable(int** table, int rows)
{
    if(table)
    {
        for(int i = 0; i < rows; i++){ if(table[i]){ delete[] table[i]; } }
        delete[] table;    
    }
}
void printTable(int** table, int rows, int columns){
    for(int i = 0; i < rows; i++){
        for(int j = 0; j < columns; j++){
            printf("(%d,%d) -> %d\n", i, j, table[i][j]);
        }    
    }
}

int main(int argc, char *argv[])
{
    Automata automata;
    string in_file, out_file;
    cout << "Bienvenido al programa que convierte un automata NFA con movimientos nulos a un automata DFA, dado una 5 tupla." << endl;
    cout << "Ingresa el nombre del archivo que contiene la 5 tupla del NFA-e, debe ser .txt" << endl;
    //cin >> in_file;
    //automata.convertirAutomata(in_file);
    automata.convertirAutomata("NFA.txt");
    cout << "Ingresa el nombre de salida del archivo donde se escribira la 5 tupla del DFA, debe ser .txt" << endl;
    //cin >> out_file;
    //automata.guardarAutomataConvertido(out_file);
    automata.guardarAutomataConvertido("DFA.txt");
    return 0;
}
