#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <algorithm> //para la funcion find
#include <math.h>

using namespace std;

FILE openFile(string file_name);
vector<string> getSubstrings();
class Substring{
    private:
        vector<string> substrings;
        vector<string> aux_substrings;
        vector<string> casos_recursivos;
        vector<vector<char> > dos_variables_casos_recursivos;
        vector<vector<string> > tres_variables_casos_recursivos;
        vector<vector<string> > cuatro_variables_casos_recursivos;
        vector<vector<string> > cinco_variables_casos_recursivos;
        vector<vector<string> > seis_variables_casos_recursivos;
        int N;
        int num_casos_recursivos;
        int num_substrings;
        int aux_num_substrings;
        string caso_base;

    public:
        Substring()
        {

        }

        void readFile(string file_name)
        {
            ifstream file; //variable para leer archivo

            string contenido;
            num_casos_recursivos = 0;

            file.open(file_name.c_str(), ios::in); //abre el archivo dado para extraer datos

            if(file.fail()) //condicion para saber si el no archivo esta o no lo encontro
            {
                cout << "No se encontro el archivo para leer" << endl;
                exit(1); //si no encontro el archivo cierra el programa
            }

            getline(file,contenido);//se usa un getline para sacar el primer dato que es el caso base
            caso_base = contenido;

            cout << "Iteracion 0" << endl << caso_base << endl;
            if (caso_base == "$")
            {
                caso_base = "\0";
            }
            substrings.push_back(caso_base);//agrego siempre el caso base
            num_substrings++; //porque agregue el caso base

            //while para sacar los casos de paso recursivo
            while(getline(file,contenido))
            {
                num_casos_recursivos++;
                casos_recursivos.push_back(contenido);
            }
            //cout << casos_recursivos[0][0] << endl;
            file.close();//cierre del archivo pasado
        }

        void getSubstrings(string file_name, int N)
        {
            this->N = N;
            readFile(file_name);
            string current_string;
            string substring_actual = "";
            int num_variables_in_substring;
            //vector<string>::iterator it;
            string variables = "";
            

            for(int i = 0; i < N; i++) //para el numero de iteraciones dadas por el usuario
            {
                cout << endl << "Iteracion " << i + 1 << endl;
                aux_substrings = substrings; //guardo una copia del vector donde guardo los substrings generados para cada iteracion, evitando iterar sobre substrings generados en el mismo nivel
                aux_num_substrings = num_substrings;
                //cout << "aux num: " << aux_num_substrings << endl;
                for(int j = 0; j < num_casos_recursivos; j++) //para cada caso recursivo dado en el archivo
                {
                    current_string = casos_recursivos[j];
                    for(int k = 0; k < aux_num_substrings; k++) //para cada substring ya generados que hay dentro del vector del paso anterior
                    {
                        cout << "\nEl substring que se esta iterando es el : " << aux_substrings[k] << endl;
                        variables = "";
                        num_variables_in_substring = getNumberVariables(current_string, variables);
                        num_variables_in_substring = pow(2, num_variables_in_substring);
                        cout << "variables: " << variables <<  " con " << num_variables_in_substring << endl;
                        for (int x = 1; x < (num_variables_in_substring+1); x++) 
                        {
                            cout << "X : " << x << endl;
                            for(int p = 0; p < current_string.length(); p++) //para iterar sobre la palabra de los casos recursivos y saber donde intercambiar u-z por los substrings generados anteriormente
                            {
                                if (current_string[p] >= 117 && current_string[p] <= 122) //En ascii: 117-122 (u-w)
                                {
                                    int index = getIndexVariable(dos_variables_casos_recursivos[0], current_string[p]);
                                    cout << "the index is: " << index  << " -> variable = " << dos_variables_casos_recursivos[0][index] << endl;
                                    cout << "variables[" << x << "][" << index << "] = " << dos_variables_casos_recursivos[x][index] << endl;
                                    if (dos_variables_casos_recursivos[x][index] == '1') 
                                    {
                                        //cout << "JALA PERROO" << endl;
                                        cout << "**Hay una " << current_string[p] << ". Se sustituyo por " << aux_substrings[k] << "**" << endl;
                                        substring_actual += aux_substrings[k]; //concateno
                                    }
                                    else
                                    {
                                        //substring_actual += aux_substrings[k]; //concateno
                                        //no concateno pprque es nulo
                                    }
                                }
                                else
                                {
                                    substring_actual += current_string[p];
                                }
                            }
                            cout << "****El substring que se genero es_: " << substring_actual << endl;
                            if ((find(substrings.begin(), substrings.end(), substring_actual) != substrings.end()) == false) //si no se encuentra el substring generado lo agrego
                            {
                                cout << "Substring generado: " << substring_actual << endl;
                                substrings.push_back(substring_actual); //guardo el substring generado
                                num_substrings++;
                            }
                            substring_actual = "";
                        }
                    }
                }
            }
            cout << "Items: " << num_substrings << endl;
        }

        void function(vector<int> all_combinations, int num_variables, string palabra){
            vector<string> aux_combination;
            string aux_palabra;
            for(int i = 0; i < num_variables; i++)
            {
                for(int j = 0; j < palabra.length(); j++)
                {
                    
                    for(int k = 1; k < all_combinations.size(); k++)
                    {
                        aux_palabra = palabra;
                        if (palabra[j] == all_combinations[i]) {
                            aux_palabra[j] == all_combinations[k];
                            aux_combination.push_back(aux_palabra);
                            aux_combination.pop_front();
                        }
                        
                    }
                }
            }
            
        }

         // The main recursive method to print all possible combinatrions of length "length"
        void combinations(vector<string> str, string prefix, const int n, const int lenght, vector<string> &variables)
        {
            //cout << prefix  << " " << endl;
            if (lenght == 1)
            {
                for (int j = 0; j < n; j++)
                {
                    cout << prefix << " " << str[j] << std::endl;
                    variables.push_back(prefix+str[j]);
                }
            }//Base case: lenght = 1, print the string "lenght" times + the remaining letter
            else
            {
            // One by one add all characters from "str" and recursively call for "lenght" equals to "lenght"-1
                for (int i = 0; i < n; i++)
                {
                    // Next character of input added
                    combinations(str, prefix + str[i], n, lenght - 1, variables);
                    // "lenght" is decreased, because we have added a new character
                }
            }
        }

        // Funcion para obtener las permutaciones de una palabra (paso inductivo) para saber sus posibles valores
        int getNumberVariables(string palabra, string &str_variables)
        {
            vector<char> variables;
            int num_variables = 0;
            for (int i = 0; i < palabra.length(); i++) {
                if (palabra[i] >= 117 && palabra[i] <= 122) {
                    if ((find(variables.begin(), variables.end(), palabra[i]) != variables.end()) == false) //si no se encuentra el substring generado lo agrego
                    {
                        variables.push_back(palabra[i]);
                        str_variables += palabra[i];
                        num_variables++;
                    }
                }
            }
            dos_variables_casos_recursivos.clear();
            dos_variables_casos_recursivos.push_back(variables);
                variables.clear();
            //cout << "Variables desde func: "<< str_variables << " con (num varia)" << num_variables << endl;
            if (num_variables == 2) 
            {
                
                variables.push_back('0');
                variables.push_back('0');
                dos_variables_casos_recursivos.push_back(variables);
                variables.clear();

                variables.push_back('0');
                variables.push_back('1');
                dos_variables_casos_recursivos.push_back(variables);
                variables.clear();

                variables.push_back('1');
                variables.push_back('0');
                dos_variables_casos_recursivos.push_back(variables);
                variables.clear();
                
                variables.push_back('1');
                variables.push_back('1');
                dos_variables_casos_recursivos.push_back(variables);
                variables.clear();                
            }
            else
            {
                variables.push_back('1');
                variables.push_back('1');
                dos_variables_casos_recursivos.push_back(variables);
                variables.clear();
            }
            return num_variables;
        }

        int getIndexVariable(vector <char> variables, char given_variable)
        {
            for(int i = 0; i < variables.size(); i++)
            {
                if (variables[i] == given_variable) 
                {
                    return i;
                }
            }
            return -1;
        }
};


/*
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <algorithm> //para la funcion find

using namespace std;

FILE openFile(string file_name);
vector<string> getSubstrings();
class Substring{
    private:
        vector<string> substrings;
        vector<string> aux_substrings;
        vector<string> casos_recursivos;
        int N;
        int num_casos_recursivos;
        int num_substrings;
        int aux_num_substrings;
        string caso_base;

    public:
        Substring(){}

        void readFile(string file_name)
        {
            ifstream file; //variable para leer archivo

            string contenido;
            num_casos_recursivos = 0;

            file.open(file_name.c_str(), ios::in); //abre el archivo dado para extraer datos

            if(file.fail()) //condicion para saber si el no archivo esta o no lo encontro
            {
                cout << "No se encontro el archivo para leer" << endl;
                exit(1); //si no encontro el archivo cierra el programa
            }

            getline(file,contenido);//se usa un getline para sacar el primer dato que es el caso base
            caso_base = contenido;

            cout << "Iteracion 0" << endl << caso_base << endl;
            if (caso_base == "$")
            {
                caso_base = "\0";
            }
            substrings.push_back(caso_base);//agrego siempre el caso base
            num_substrings++; //porque agregue el caso base

            //while para sacar los casos de paso recursivo
            while(getline(file,contenido))
            {
                num_casos_recursivos++;
                casos_recursivos.push_back(contenido);
            }
            //cout << casos_recursivos[0][0] << endl;
            file.close();//cierre del archivo pasado
        }

        void getSubstrings(string file_name, int N)
        {
            this->N = N;
            readFile(file_name);
            string current_string;
            string substring_actual = "";

            for(int i = 0; i < N; i++) //para el numero de iteraciones dadas por el usuario
            {
                cout << endl << "Iteracion " << i + 1 << endl;
                aux_substrings = substrings; //guardo una copia del vector donde guardo los substrings generados para cada iteracion, evitando iterar sobre substrings generados en el mismo nivel
                aux_num_substrings = num_substrings;
                //cout << "aux num: " << aux_num_substrings << endl;
                for(int j = 0; j < num_casos_recursivos; j++) //para cada caso recursivo dado en el archivo
                {
                    current_string = casos_recursivos[j];
                    for(int k = 0; k < aux_num_substrings; k++) //para cada substring ya generados que hay dentro del vector del paso anterior
                    {
                        for(int p = 0; p < current_string.length(); p++) //para iterar sobre la palabra y saber donde intercambiar u-z por los substrings generados anteriormente
                        {
                            if (current_string[p] >= 117 && current_string[p] <= 122) //En ascii: 117-122 (u-w)
                            {
                                //cout << "**Hay una " << current_string[p] << ". Se sustituyo por " << aux_substrings[k] << "**" << endl;
                                substring_actual += aux_substrings[k]; //concateno
                            }
                            else
                            {
                                substring_actual += current_string[p];
                            }
                        }
                        if ((find(substrings.begin(), substrings.end(), substring_actual) != substrings.end()) == false) //si no se encuentra el substring generado lo agrego
                        {
                            cout << "Substring generado: " << substring_actual << endl;
                            substrings.push_back(substring_actual); //guardo el substring generado
                            num_substrings++;
                        }
                        substring_actual = "";
                    }
                }
            }
            //cout << "Items: " << substrings.size() << endl;
        }

        void printSubstrings()
        {

        }
};

*/






/*

void getSubstrings(string file_name, int N)
        {
            this->N = N;
            readFile(file_name);
            string current_string;
            string substring_actual = "";
            int num_variables_in_substring;
            //vector<string>::iterator it;
            string variables = "";
            

            for(int i = 0; i < N; i++) //para el numero de iteraciones dadas por el usuario
            {
                cout << endl << "Iteracion " << i + 1 << endl;
                aux_substrings = substrings; //guardo una copia del vector donde guardo los substrings generados para cada iteracion, evitando iterar sobre substrings generados en el mismo nivel
                aux_num_substrings = num_substrings;
                //cout << "aux num: " << aux_num_substrings << endl;
                for(int j = 0; j < num_casos_recursivos; j++) //para cada caso recursivo dado en el archivo
                {
                    current_string = casos_recursivos[j];
                    for(int k = 0; k < aux_num_substrings; k++) //para cada substring ya generados que hay dentro del vector del paso anterior
                    {
                        cout << "\nEl substring que se esta iterando es el : " << aux_substrings[k] << endl;
                        variables = "";
                        num_variables_in_substring = getNumberVariables(current_string, variables);
                        num_variables_in_substring = pow(2, num_variables_in_substring);
                        cout << "variables: " << variables <<  " con " << num_variables_in_substring << endl;
                        for (int x = 1; x < (num_variables_in_substring+1); x++) 
                        {
                            cout << "X : " << x << endl;
                            for(int p = 0; p < current_string.length(); p++) //para iterar sobre la palabra de los casos recursivos y saber donde intercambiar u-z por los substrings generados anteriormente
                            {
                                if (current_string[p] >= 117 && current_string[p] <= 122) //En ascii: 117-122 (u-w)
                                {
                                    int index = getIndexVariable(dos_variables_casos_recursivos[0], current_string[p]);
                                    cout << "the index is: " << index  << " -> variable = " << dos_variables_casos_recursivos[0][index] << endl;
                                    cout << "variables[" << x << "][" << index << "] = " << dos_variables_casos_recursivos[x][index] << endl;
                                    if (dos_variables_casos_recursivos[x][index] == '1') 
                                    {
                                        //cout << "JALA PERROO" << endl;
                                        cout << "**Hay una " << current_string[p] << ". Se sustituyo por " << aux_substrings[k] << "**" << endl;
                                        substring_actual += aux_substrings[k]; //concateno
                                    }
                                    else
                                    {
                                        //substring_actual += aux_substrings[k]; //concateno
                                        //no concateno pprque es nulo
                                    }
                                }
                                else
                                {
                                    substring_actual += current_string[p];
                                }
                            }
                            cout << "****El substring que se genero es_: " << substring_actual << endl;
                            if ((find(substrings.begin(), substrings.end(), substring_actual) != substrings.end()) == false) //si no se encuentra el substring generado lo agrego
                            {
                                cout << "Substring generado: " << substring_actual << endl;
                                substrings.push_back(substring_actual); //guardo el substring generado
                                num_substrings++;
                            }
                            substring_actual = "";
                        }
                    }
                }
            }
            cout << "Items: " << num_substrings << endl;
        }

*/