#include "definiciones_recursivas.h"

int main(){
    string file_name;
    int N;

    cout << "Dame el nombre del archivo\n";
    cin >> file_name;
    cout << "Cuantas veces quieres hacer el paso recursivo\n";
    cin >> N;
    Substring substring;
    //substring.getSubstrings(file_name, N);

    int lenght = 3;
    
    std::vector<string> variables;

    variables.push_back("00");
    variables.push_back("11");

    variables.push_back("22");

    vector<string> vect;

    int n = variables.size();

    substring.combinations(variables, "", n, lenght, vect);  //Note: this function works on all cases and not just the case above

    cout  << endl << vect[0] <<  " " << vect[1] << " " << vect[2] << endl;

    if (vect[0] == "\0") {
        cout << "Simon " << endl;
    }
    

    return 0;
}
